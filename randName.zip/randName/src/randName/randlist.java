package randName;
import java.util.*;
public class randlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list=new ArrayList<String>();
		list.add("Sudhakar R");
		list.add("Laxmipathi� Raju Dantuluri");
		list.add("Lalit Kumar Desh Mukh");
		list.add("Devaprasad Sarekokku");
		list.add("Arundathi S");
		list.add("Trisha Bhattacharyya");
		list.add("Chitra Singh");
		list.add("Amit Kumar Maurya");
		list.add("Kolla Ravi Chandar");
		list.add("Chandresh r");
		list.add("Santosh Kumar Patra ");
		list.add("Abburu Srinivas");
		list.add("Reeva Mishra");
		list.add("Neelkant Bhargava");
		list.add("Utkarsh Ashu");
		list.add("Dasthothi Ranjith");
		list.add("Ramu");
		list.add("Chinna Reddy Yeulluri");
		list.add("Chaitanya Naik");
		list.add("Aravind Dinakaran");
		list.add("Umesha CS");
		list.add("Deepshikha Sinha");
		list.add("Vandana Gupta");
		list.add("Anuthama Koti");
		list.add("Veeranna");
		list.add("Rakesh N");
		list.add("Gourav Panwar");
		list.add("Nitheesh shetty");
		list.add("Ajith a");
		list.add("Chandra Sekhar");
		list.add("Dattaguru bhat");
		list.add("Nanjunda rathod");
		list.add("Anil Salagare");
		list.add("Padmakant Prakash Baloji");
		list.add("Pradeep Andru ");
		list.add("Shwetangi Sah");
		list.add("Amey Ramakrishna");
		list.add("Megha Kumari");
		list.add("Ajay Police Patil");
		list.add("Afroz Ansari");
		list.add("Silvi Sinha");
		list.add("Sadanand Sonkar");
		list.add("Sowgharthigha M");
		list.add("Yuvaraj K");
		list.add("Dattaswarup  V Kamat Satoskar");
		list.add("Pratyush Ranjan");
		list.add("Darshan AR");
		list.add("Priyanka S");
		
		Random rand=new Random();
		int result=rand.nextInt(list.size());
		System.out.println(list.get(result));

	}

}
